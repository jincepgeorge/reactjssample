import React from 'react'

export const LanguageSelection = () => {
    return (
        <div>
            Language Selection Comp.
        </div>
    )
}

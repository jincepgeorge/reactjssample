import React from 'react'

export function SharedComp() {
    return (
        <div>
            I am a Shared Component from "./Components"
        </div>
    )
}

export const ROOT = "/";
export const LOGIN = "/login";
export const DASHBOARD = "/dashboard";
export const PAGE1 = "/page1";
export const AUTH_PAGE1 = "/authorized1";

import React from 'react'
import { Typography } from '@material-ui/core'

export const DashboardView = () => {
    return (
        <div>
            <Typography variant="h2">Dashboard Page</Typography>
        </div>
    )
}
